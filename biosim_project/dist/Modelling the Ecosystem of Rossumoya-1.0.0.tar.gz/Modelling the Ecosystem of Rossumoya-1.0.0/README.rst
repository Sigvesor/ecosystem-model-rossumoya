Making the Island, setting the scene.
=====================================

.. automodule:: biosim.island
   :members:
