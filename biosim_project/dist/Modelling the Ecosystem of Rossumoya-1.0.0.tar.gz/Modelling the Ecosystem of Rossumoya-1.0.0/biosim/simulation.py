# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
#from biosim.landscape import *
import random
from .island import *
#from landscape import *
#from animals import *
#from map_constructor import *
import pandas as pd
import numpy as np
#from math import exp as e
__author__ = 'Sigve Sorensen', 'Filip Rotnes'
__email__ = 'sigvsore@nmbu.no', 'firo@nmbu.no'

"""
This program will simulate the ecosystem of Rossumøya
"""


class BioSim:

    """
    This class instantiates an ecosystem simulation
    """

    version = '1.0'

    def __init__(self, island_map, ini_pop, seed):
        """
        Creates the variables associated with the class

        :param island_map: multi line string
        :param ini_pop: initial population in simulation
        :param seed: random seed
        """

        random.seed(seed)
        self.year = 0
        self.ini_pop = ini_pop # trengs denne? ee nei
        self.island = Island()
        self.island.populated_island(island_map, ini_pop)
        n_rows, n_cols = len(self.island.map_str), len(self.island.map[0])
        self.herb_list = [self.island.total_island_population[0]]   # disse trenger ikke være self, kanskje?
        self.carn_list = [self.island.total_island_population[1]]   # disse trenger ikke være self, kanskje?
        #self.pop_by_species = {'Herbivores': self.herb_list[-1],    # disse trenger ikke være self, kanskje?
        #                       'Carnivores': self.carn_list[-1]}
        df_cols = ['x', 'y', 'Herbivores', 'Carnivores']
        pop = pd.DataFrame(self.island.population_distribution,
                           columns= df_cols[2:4])
        empty_df = [[i+1, j+1, 0, 0] for j in range(n_cols)
                    for i in range(n_rows)]
        self.pop_by_cell = pd.DataFrame(data= empty_df, columns=df_cols)
        self.pop_by_cell.update(pop)

    @property
    def population_by_cell(self):
        """
        Returns a DataFrame containing the number of each species per cell
        Columns: 'x', 'y', 'Herbivores', 'Carnivores'

        :return: pandas.DataFrame
        """
        pop = pd.DataFrame(self.island.population_distribution,
                           columns=['Herbivores', 'Carnivores'])
        self.pop_by_cell.update(pop)
        return self.pop_by_cell

    @property
    def population_by_species(self):
        """
        Returns a dictionary containing the number of animals for each species.

        :return: dict
        """

        herbs = self.herb_list[-1]
        carns = self.carn_list[-1]
        return {'Herbivores': herbs, 'Carnivores': carns}

    @property
    def years_passed(self):
        """
        Returns the number of years the BioSim instance has simulated

        :return: int
        """

        return self.year

    @property
    def total_animals(self):
        """
        Returns the total number of animals

        :return: int
        """

        return self.herb_list[-1] + self.carn_list[-1]

    def simulate(self, num_steps, vis_steps=None, img_steps=None):
        """
        Conducting the simulation, deciding number of cycles.

        :param num_steps: int
        :param vis_steps: int
        :param img_steps: int
        """

        for step in range(num_steps):
            sim_cyc = self.island.cycle()
            self.herb_list.append(sim_cyc[0])
            self.carn_list.append(sim_cyc[1])
            self.year += 1
            print(self.year)
            print(self.herb_list)
            print(self.carn_list)

    def add_population(self, population=None):
        """
        Adds populations from a list of dictionaries
        The keys of the dictionaries have to be 'species', 'age' and 'weight'

        :param population: list
        """

        self.island.distribute_animals(population)

    def sim_plot(self):
        """
        Plots the results of the simulation
        """
        plt.plot(range(len(self.herb_list)), self.herb_list, 'r-',
                 range(len(self.carn_list)), self.carn_list, 'b-')
        plt.show()

    def heat_map(self, herbivore=True):
        """
        Returns a heat-map, describing population density and movements

        :param herbivore: bool
        :return: plot
        """

        if herbivore:
            col = 'Greens'
            species = 'Herbivores'
        else:
            col = 'Reds'
            species = 'Carnivores'
        df = self.population_by_cell

        pop_array = self.island.population_array()
        heatmap = plt.imshow(pop_array, cmap=col, interpolation='nearest')
        return heatmap

    def plot_pop_density(self):
        """
        Plots the population density

        :return: plot
        """
        fig = plt.plot(range(len(self.herb_list)), self.herb_list, 'r-',
                       range(len(self.carn_list)), self.carn_list, 'b-')
        return fig


if __name__ == "__main__":
    import timeit

    t0 = timeit.default_timer()

    kart = """OOOOOOOOOOOOOOOOOOOOO
        OOOOOOOOSMMMMJJJJJJJO
        OSSSSSJJJJMMJJJJJJJOO
        OSSSSSSSSSMMJJJJJJOOO
        OSSSSSJJJJJJJJJJJJOOO
        OSSSSSJJJDDJJJSJJJOOO
        OSSJJJJJDDDJJJSSSSOOO
        OOSSSSJJJDDJJJSOOOOOO
        OSSSJJJJJDDJJJJJJJOOO
        OSSSSJJJJDDJJJJOOOOOO
        OOSSSSJJJJJJJJOOOOOOO
        OOOSSSSJJJJJJJOOOOOOO
        OOOOOOOOOOOOOOOOOOOOO"""

    ini_herbs = [{'loc': (2, 20),
                  'pop': [{'species': 'Herbivore', 'age': 5,
                           'weight': 20} for _ in range(150)]}]
    ini_carns = [{'loc': (2, 20),
                  'pop': [{'species': 'Carnivore', 'age': 5,
                           'weight': 20} for _ in range(40)]}]
    sim = BioSim(ini_pop=ini_herbs, island_map=kart, seed=12634)

    sim.simulate(50)
    sim.add_population(ini_carns)
    sim.simulate(400)
    sim.sim_plot()
    print(timeit.default_timer() - t0)
    # plt.show()
